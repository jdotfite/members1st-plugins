// Frontend JavaScript
console.log("Custom button loaded");
