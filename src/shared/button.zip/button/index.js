// src/shared/button/index.js
export { Button } from './components/button';
export * from './constants';